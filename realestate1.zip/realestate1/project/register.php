<?php

include 'components/connect.php'; // Perfshin skedarin per lidhjen me bazen e te dhenave.

// Kontrollon nese ekziston nje cookie per ID e perdoruesit dhe e ruan ate ne nje variabel.
if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = ''; // Nese nuk ekziston cookie, vendoset si varg bosh.
}

// Kontrollon nese eshte shtypur butoni i dergimit ne forme dhe fillon procesimin e te dhenave te formes.
if(isset($_POST['submit'])){

   // Gjeneron nje ID unike per perdoruesin dhe pastron te dhenat e hyra per te parandaluar sulmet e injektimit.
   $id = create_unique_id(); // Kjo funksion do te krijoje nje identifikator unik per cdo perdorues te ri.
   $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING); // Pastron emrin nga karakteret e padeshiruara.
   $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING); // Pastron numrin e telefonit.
   $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING); // Pastron email-in.
   $pass = sha1($_POST['pass']); // Hashon fjalekalimin e dhene nga perdoruesi per siguri shtese.
   $c_pass = sha1($_POST['c_pass']); // Hashon konfirmimin e fjalekalimit per krahasim.

   // Kontrollon nese email-i i dhene nga perdoruesi tashme ekziston ne bazen e te dhenave.
   $select_users = $conn->prepare("SELECT * FROM `users` WHERE email = ?");
   $select_users->execute([$email]);

   // Nese gjen nje perdorues me te njejtin email, shfaqet nje mesazh paralajmerues.
   if($select_users->rowCount() > 0){
      $warning_msg[] = 'Email-i eshte i perdorur!'; 
   }else{
      // Kontrollon nese fjalekalimet perputhen.
      if($pass != $c_pass){
         $warning_msg[] = 'Password nuk eshte i njejte!';
      }else{
         // Nese te gjitha kontrollimet jane ne rregull, shton te dhenat e perdoruesit te ri ne bazen e te dhenave.
         $insert_user = $conn->prepare("INSERT INTO `users`(id, name, number, email, password) VALUES(?,?,?,?,?)");
         $insert_user->execute([$id, $name, $number, $email, $c_pass]);
         
         // Kontrollon nese shtimi ne bazen e te dhenave ishte i suksesshem dhe vendos nje cookie per ID e perdoruesit.
         if($insert_user){
            $verify_users = $conn->prepare("SELECT * FROM `users` WHERE email = ? AND password = ? LIMIT 1");
            $verify_users->execute([$email, $pass]);
            if($verify_users->rowCount() > 0){
               $row = $verify_users->fetch(PDO::FETCH_ASSOC);
               setcookie('user_id', $row['id'], time() + 60*60*24*30, '/');
               header('location:home.php'); // Ridrejton perdoruesin ne faqen kryesore pas regjistrimit te suksesshem.
            }else{
               $error_msg[] = 'Gabim ne regjistrim!'; // Shfaqet nese ka nje problem gjate procesit te verifikimit.
            }
         }
      }
   }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="form-container">

   <form action="" method="post">
      <h3>Krijoni nje llogari!</h3>
      <input type="tel" name="name" required maxlength="50" placeholder="Vendosni emrin" class="box">
      <input type="email" name="email" required maxlength="50" placeholder="Vendosni email-in" class="box">
      <input type="number" name="number" required min="0" max="9999999999" maxlength="10" placeholder="Vendosni numrin e telfonit" class="box">
      <input type="password" name="pass" required maxlength="20" placeholder="Vendosni password-in" class="box">
      <input type="password" name="c_pass" required maxlength="20" placeholder="Konfirmoni password-in" class="box">
      <p>Ju e keni nje llogari? <a href="login.html">login </a></p>
      <input type="submit" value="Regjistrohu" name="submit" class="btn">
   </form>

</section>


<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<?php include 'components/footer.php'; ?>

<script src="js/script.js"></script>

<?php include 'components/message.php'; ?>

</body>
</html>
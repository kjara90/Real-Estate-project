<?php

   // Percakton te dhenat per lidhjen me bazen e te dhenave perdorur PDO.
$db_name = 'mysql:host=localhost;dbname=home_db'; // Hosti dhe emri i bazes se te dhenave.
$db_user_name = 'root'; // Emri i perdoruesit per bazen e te dhenave.
$db_user_pass = ''; // Fjalekalimi per perdoruesin e bazes se te dhenave, bosh per perdoruesin root pa fjalekalim.

// Krijon nje objekt te ri PDO per lidhjen me bazen e te dhenave duke perdorur te dhenat e mesiperme.
$conn = new PDO($db_name, $db_user_name, $db_user_pass);

// Definon nje funksion per te krijuar nje ID unik.
function create_unique_id(){
   // Percakton karakteret qe do te perdoren per te gjeneruar stringun e rastesishem.
   $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   $charactersLength = strlen($characters); // Merr gjatesine e vargut te karaktereve per perdorim ne ciklin for.
   $randomString = ''; // Inicializon vargun qe do te mbaje ID e gjeneruar.

   // Gjeneron nje string rastesishem me gjatesi 20 karaktere.
   for ($i = 0; $i < 20; $i++) {
       $randomString .= $characters[mt_rand(0, $charactersLength - 1)]; // Shton nje karakter te rastesishem ne stringun e rastesishem.
   }
   return $randomString; // Kthen stringun e gjeneruar si ID unik.
}

?>
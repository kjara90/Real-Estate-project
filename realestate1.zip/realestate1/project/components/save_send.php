<?php
// Kontrollon nese eshte shtypur butoni 'Ruaj'.
if(isset($_POST['save'])){
   // Kontrollon nese perdoruesi eshte i loguar.
   if($user_id != ''){

      // Gjeneron nje ID unik per te ruajtur dhe merr ID e prones nga forma.
      $save_id = create_unique_id();
      $property_id = filter_var($_POST['property_id'], FILTER_SANITIZE_STRING);

      // Verifikon nese prona eshte tashme e ruajtur nga perdoruesi.
      $verify_saved = $conn->prepare("SELECT * FROM `saved` WHERE property_id = ? and user_id = ?");
      $verify_saved->execute([$property_id, $user_id]);

      // Nese prona eshte e ruajtur, e heq ate nga lista e te ruajturave.
      if($verify_saved->rowCount() > 0){
         $remove_saved = $conn->prepare("DELETE FROM `saved` WHERE property_id = ? AND user_id = ?");
         $remove_saved->execute([$property_id, $user_id]);
         $success_msg[] = 'Fshije nga saved!';
      }else{
         // Nese prona nuk eshte e ruajtur, e shton ate ne lista e te ruajturave.
         $insert_saved = $conn->prepare("INSERT INTO`saved`(id, property_id, user_id) VALUES(?,?,?)");
         $insert_saved->execute([$save_id, $property_id, $user_id]);
         $success_msg[] = 'listo saved!';
      }

   }else{
      // Shfaq nje mesazh paralajmerues nese perdoruesi nuk eshte i loguar.
      $warning_msg[] = 'Fillimisht logohu!';
   }
}

// Kontrollon nese eshte shtypur butoni 'Dergo Kerkese'.
if(isset($_POST['send'])){
   // Kontrollon nese perdoruesi eshte i loguar.
   if($user_id != ''){

      // Gjeneron nje ID unik per kerkesen dhe merr ID e prones nga forma.
      $request_id = create_unique_id();
      $property_id = filter_var($_POST['property_id'], FILTER_SANITIZE_STRING);

      // Merr ID e perdoruesit qe posedon pronen.
      $select_receiver = $conn->prepare("SELECT user_id FROM `property` WHERE id = ? LIMIT 1");
      $select_receiver->execute([$property_id]);
      $fetch_receiver = $select_receiver->fetch(PDO::FETCH_ASSOC);
      $receiver = $fetch_receiver['user_id'];

      // Verifikon nese nje kerkese per te njejten prone nga i njejti dergues eshte bere me pare.
      $verify_request = $conn->prepare("SELECT * FROM `requests` WHERE property_id = ? AND sender = ? AND receiver = ?");
      $verify_request->execute([$property_id, $user_id, $receiver]);

      // Nese kerkesa ekziston, shfaq nje mesazh paralajmerues.
      if(($verify_request->rowCount() > 0)){
         $warning_msg[] = 'Kerkesa po dergohet!';
      }else{
         // Nese nuk ekziston, shton kerkesen ne bazen e te dhenave.
         $send_request = $conn->prepare("INSERT INTO `requests`(id, property_id, sender, receiver) VALUES(?,?,?,?)");
         $send_request->execute([$request_id, $property_id, $user_id, $receiver]);
         $success_msg[] = 'Kerkesa u dergua!';
      }

   }else{
      // Shfaq nje mesazh paralajmerues nese perdoruesi nuk eshte i loguar.
      $warning_msg[] = 'Fillimisht logohu!';
   }
}
?>

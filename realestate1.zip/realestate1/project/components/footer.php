
<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:1234567890"><i class="fas fa-phone"></i><span>123456789</span></a>
         <a href="tel:1112223333"><i class="fas fa-phone"></i><span>1112223333</span></a>
         <a href="mailto:shaikhanas@gmail.com"><i class="fas fa-envelope"></i><span>paw_realestate@gmail.com</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span>PAW</span></a>
      </div>

      <div class="box">
         <a href="home.php"><span>Kreu</span></a>
         <a href="about.php"><span>Rreth nesh</span></a>
         <a href="contact.php"><span>Kontakte</span></a>
         <a href="listings.php"><span>Listimet</span></a>
         <a href="saved.php"><span>Saved</span></a>
      </div>

      <div class="box">
         <a href="#"><span>facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="#"><span>twitter</span><i class="fab fa-twitter"></i></a>
         <a href="#"><span>linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="#"><span>instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>PAW.FEUT</span> | all rights reserved!</div>

</footer>


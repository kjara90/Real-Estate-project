<?php
// Inkludon skedarin qe permban kodin per lidhjen me bazen e te dhenave.
include 'connect.php';

// Fshin cookie-ne 'admin_id' duke caktuar nje kohe te skadimit ne te kaluaren, keshtu ben qe cookie te mos jete me i vlefshem.
setcookie('admin_id', '', time() - 1, '/');

// Ridrejton perdoruesin ne faqen e logimit te adminit, duke e derguar ate larg nga zona e adminit pasi eshte ç'loguar.
header('location:../admin/login.php');
?>

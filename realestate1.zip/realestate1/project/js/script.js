// Merr elementin e menyse nga struktura e header-it.
let menu = document.querySelector('.header .menu');

// Vendos nje degjues te ngjarjeve qe aktivizon ose çaktivizon klasen 'active' ne menyne kur klikohet butoni i menyse.
document.querySelector('#menu-btn').onclick = () =>{
   menu.classList.toggle('active');
}

// Heq klasen 'active' nga menya kur perdoruesi leviz faqen per te shmangur shfaqjen e menyse gjate skrollimit.
window.onscroll = () =>{
   menu.classList.remove('active');
}

// Vendos degjues te ngjarjeve ne te gjitha inputet numerike per te kufizuar numrin e karaktereve te lejuara.
document.querySelectorAll('input[type="number"]').forEach(inputNumber => {
   inputNumber.oninput = () =>{
      // Kufizon gjatesine e inputit ne maksimumin e lejuar, duke prere çdo karakter shtese.
      if(inputNumber.value.length > inputNumber.maxLength) inputNumber.value = inputNumber.value.slice(0, inputNumber.maxLength);
   };
});

// Vendos degjues te ngjarjeve ne titujt e kutive te FAQ per te lejuar perdoruesit te shfaqin ose fshehin pergjigjet.
document.querySelectorAll('.faq .box-container .box h3').forEach(headings =>{
   headings.onclick = () =>{
      // Aktivizon ose çaktivizon klasen 'active' ne elementin prind per te kontrolluar shfaqjen e pergjigjes.
      headings.parentElement.classList.toggle('active');
   }
});

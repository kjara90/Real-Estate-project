<?php  

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
   header('location:login.php');
}

include 'components/save_send.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Te ruajtura</title>

   
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<section class="listings">

   <h1 class="heading">Pronat e ruajtura</h1>

   <div class="box-container">
   <?php  
include 'components/connect.php'; // Inkludon skedarin per lidhjen me bazen e te dhenave

// Kontrollon nese ekziston nje cookie per ID e perdoruesit. Nese nuk ekziston, perdoruesi ridrejtohet ne faqen e logimit.
if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id']; // Merr vleren e ID se perdoruesit nga cookie
}else{
   $user_id = ''; // Cakton variablen user_id si varg bosh nese nuk ekziston cookie per ID e perdoruesit
   header('location:login.php'); // Ridrejton perdoruesin ne faqen e logimit
}

// Kontrollon nese ka te dhena te ruajtura per perdoruesin aktual dhe i merr ato nga baza e te dhenave
if(isset($_POST['delete'])){
   $delete_id = $_POST['request_id']; // Merr ID e kerkeses nga forma
   $delete_id = filter_var($delete_id, FILTER_SANITIZE_STRING); // Pastron ID e kerkeses per siguri

   // Verifikon nese ekziston nje kerkese me ate ID ne bazen e te dhenave
   $verify_delete = $conn->prepare("SELECT * FROM `requests` WHERE id = ?");
   $verify_delete->execute([$delete_id]);

   // Nese kerkesa ekziston, ajo fshihet nga baza e te dhenave
   if($verify_delete->rowCount() > 0){
      $delete_request = $conn->prepare("DELETE FROM `requests` WHERE id = ?");
      $delete_request->execute([$delete_id]);
      $success_msg[] = 'Kerkesa u fshi!'; // Shfaq nje mesazh suksesi pas fshirjes se kerkeses
   }else{
      $warning_msg[] = 'Kerkesa eshte fshire!'; // Shfaq nje mesazh paralajmerues nese kerkesa nuk gjendet
   }
}
?>






<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

<?php include 'components/message.php'; ?>

</body>
</html>
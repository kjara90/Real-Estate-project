
<?php  

include 'components/connect.php'; // Perfshin skedarin per lidhjen me bazen e te dhenave

if(isset($_COOKIE['user_id'])){ // Kontrollon nese cookie per user_id ekziston
   $user_id = $_COOKIE['user_id']; // Merr vleren e user_id nga cookie
}else{
   $user_id = ''; // Vendos vleren e user_id si varg bosh nese cookie nuk ekziston
}

include 'components/save_send.php'; // Perfshin skedarin per ruajtjen dhe dergimin e te dhenave

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>All Listings</title> <!-- Titulli i faqes -->

   
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"> <!-- Lidhja me FontAwesome per ikona -->

   <link rel="stylesheet" href="css/style.css"> <!-- Lidhja me fajllin CSS per stilizimin -->

</head>
<body>
   
<?php include 'components/user_header.php'; ?> <!-- Perfshin header-in e perdoruesit -->


<section class="listings"> <!-- Seksioni per listimin e pronave -->

   <h1 class="heading">Listimet</h1> <!-- Titulli i seksionit -->

   <div class="box-container"> <!-- Kontejneri per kutite e listimeve -->
      <?php
         $total_images = 0; // Inicializon numrin total te imazheve
         $select_properties = $conn->prepare("SELECT * FROM `property` ORDER BY date DESC"); // Pergatit query-n per te marre pronat
         $select_properties->execute(); // Ekzekuton query-n
         if($select_properties->rowCount() > 0){ // Kontrollon nese ka rezultate
            while($fetch_property = $select_properties->fetch(PDO::FETCH_ASSOC)){ // Marrja e te dhenave te prones ne nje cikel

            $select_user = $conn->prepare("SELECT * FROM `users` WHERE id = ?"); // Pergatit query-n per te marre te dhenat e perdoruesit
            $select_user->execute([$fetch_property['user_id']]); // Ekzekuton query-n me id e perdoruesit
            $fetch_user = $select_user->fetch(PDO::FETCH_ASSOC); // Marrja e te dhenave te perdoruesit

            // Kontrollon nese ekzistojne imazhe shtese dhe llogarit numrin e tyre
            if(!empty($fetch_property['image_02'])){
               $image_coutn_02 = 1;
            }else{
               $image_coutn_02 = 0;
            }
            if(!empty($fetch_property['image_03'])){
               $image_coutn_03 = 1;
            }else{
               $image_coutn_03 = 0;
            }
            if(!empty($fetch_property['image_04'])){
               $image_coutn_04 = 1;
            }else{
               $image_coutn_04 = 0;
            }
            if(!empty($fetch_property['image_05'])){
               $image_coutn_05 = 1;
            }else{
               $image_coutn_05 = 0;
            }

            $total_images = (1 + $image_coutn_02 + $image_coutn_03 + $image_coutn_04 + $image_coutn_05); // Llogarit numrin total te imazheve

            $select_saved = $conn->prepare("SELECT * FROM `saved` WHERE property_id = ? and user_id = ?"); // Pergatit query-n per te kontrolluar nese prona eshte e ruajtur
            $select_saved->execute([$fetch_property['id'], $user_id]); // Ekzekuton query-n

      ?>
      <form action="" method="POST"> <!-- Forma per veprime mbi pronen -->
         <div class="box"> <!-- Kutia per secilen prone -->
            <input type="hidden" name="property_id" value="<?= $fetch_property['id']; ?>"> <!-- Fusha fshehur per ID e prones

 -->
            <?php
               if($select_saved->rowCount() > 0){ // Kontrollon nese prona eshte e ruajtur
            ?>
            <button type="submit" name="save" class="save"><i class="fas fa-heart"></i><span>saved</span></button> <!-- Butoni per te shenuar si te ruajtur -->
            <?php
               }else{ 
            ?>
            <button type="submit" name="save" class="save"><i class="far fa-heart"></i><span>save</span></button> <!-- Butoni per te ruajtur pronen -->
            <?php
               }
            ?>
            <div class="thumb"> <!-- Pjesa e imazhit te prones -->
               <p class="total-images"><i class="far fa-image"></i><span><?= $total_images; ?></span></p> <!-- Numri total i imazheve -->
               
               <img src="uploaded_files/<?= $fetch_property['image_01']; ?>" alt=""> <!-- Imazhi kryesor i prones -->
            </div>
            <div class="admin"> <!-- Informacioni i perdoruesit qe ka postuar pronen -->
               <h3><?= substr($fetch_user['name'], 0, 1); ?></h3> <!-- Iniciali i emrit te perdoruesit -->
               <div>
                  <p><?= $fetch_user['name']; ?></p> <!-- Emri i perdoruesit -->
                  <span><?= $fetch_property['date']; ?></span> <!-- Data e postimit -->
               </div>
            </div>
         </div>
         <div class="box">
            <div class="price">All</i><span><?= $fetch_property['price']; ?></span></div> <!-- cmimi i prones -->
            <h3 class="name"><?= $fetch_property['property_name']; ?></h3> <!-- Emri i prones -->
            <p class="location"><i class="fas fa-map-marker-alt"></i><span><?= $fetch_property['address']; ?></span></p> <!-- Adresa e prones -->
            <div class="flex">
               <p><i class="fas fa-house"></i><span><?= $fetch_property['type']; ?></span></p> <!-- Lloji i prones -->
               <p><i class="fas fa-tag"></i><span><?= $fetch_property['offer']; ?></span></p> <!-- Oferta e prones -->
               <p><i class="fas fa-bed"></i><span><?= $fetch_property['bhk']; ?> dhoma</span></p> <!-- Numri i dhomave -->
               <p><i class="fas fa-trowel"></i><span><?= $fetch_property['status']; ?></span></p> <!-- Statusi i prones -->
               <p><i class="fas fa-couch"></i><span><?= $fetch_property['furnished']; ?></span></p> <!-- Mobilimi -->
               <p><i class="fas fa-maximize"></i><span><?= $fetch_property['carpet']; ?>M2</span></p> <!-- Madhesia ne metra katrore -->
            </div>
            <div class="flex-btn">
               <a href="view_property.php?get_id=<?= $fetch_property['id']; ?>" class="btn">Shiko pronen</a> <!-- Butoni per te pare detajet e prones -->
               <input type="submit" value="Dergo kerkese" name="send" class="btn"> <!-- Butoni per te derguar kerkese -->
            </div>
         </div>
      </form>
      <?php
         }
      }else{
         echo '<p class="empty">Nuk eshte shtuar asnje prone! <a href="post_property.php" style="margin-top:1.5rem;" class="btn">add new</a></p>'; // Mesazhi nese nuk ka prone per te shfaqur
      }
      ?>
      
   </div>

</section>






<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script> <!-- Skripta per SweetAlert -->

<?php include 'components/footer.php'; ?> <!-- Perfshin footer-in -->

<script src="js/script.js"></script> <!-- Lidhja me skripten JS per funksionalitet te personalizuar -->

<?php include 'components/message.php'; ?> <!-- Perfshin pjesen per shfaqjen e mesazheve -->

</body>
</html>
